# Divyanshu Vishwakarma — Portfolio

A React portfolio website customized with Divyanshu's current profile, learning areas, and project concepts.

## Run locally

```bash
npm install
npm start
```

## Personalize your details

Edit `public/resumeData.json` to add or update:
- Public email and social profile links
- A profile photo in `public/images/`
- Verified education details
- Project URLs and screenshots
- Any real work experience or certifications

The portfolio intentionally does not publish a phone number, street address, email address, or social profile until verified details are supplied. Project entries describe concepts and should be updated as projects become publicly available.
