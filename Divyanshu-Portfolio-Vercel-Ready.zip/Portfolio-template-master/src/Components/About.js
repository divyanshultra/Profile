import React from "react";

const About = ({ data = {} }) => (
  <section id="about">
    <div className="row">
      <div className="nine columns main-col">
        <h2>About Me</h2>
        <p>{data.bio}</p>
        <div className="row">
          <div className="columns contact-details">
            <h2>Profile</h2>
            <p className="address"><span>{data.name}</span><br /><span>{data.occupation}</span><br /><span>{data.address && data.address.city}, {data.address && data.address.state}</span></p>
          </div>
        </div>
      </div>
    </div>
  </section>
);
export default About;
