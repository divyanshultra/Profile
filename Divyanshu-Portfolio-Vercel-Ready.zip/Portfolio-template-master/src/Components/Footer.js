import React from "react";

const Footer = ({ data = {} }) => (
  <footer>
    <div className="row">
      <div className="twelve columns">
        <ul className="copyright">
          <li>© {new Date().getFullYear()} {data.name || "Portfolio"}. Built with curiosity and code.</li>
        </ul>
      </div>
      <div id="go-top"><a className="smoothscroll" title="Back to Top" href="#home"><i className="icon-up-open"></i></a></div>
    </div>
  </footer>
);
export default Footer;
