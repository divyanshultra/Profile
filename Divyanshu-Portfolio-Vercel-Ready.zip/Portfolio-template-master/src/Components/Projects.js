import React from "react";

const Projects = ({ data = {} }) => {
  const projects = data.projects || [];
  return (
    <section id="portfolio">
      <div className="row">
        <div className="twelve columns collapsed">
          <h1>Selected Projects</h1>
          <div className="row">
            {projects.map(project => (
              <div className="four columns" key={project.title}>
                <div className="portfolio-item">
                  <h3>{project.title}</h3>
                  <p><strong>{project.category}</strong></p>
                  <p>{project.description}</p>
                  {project.url ? <p><a href={project.url} target="_blank" rel="noopener noreferrer">View project</a></p> : null}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
export default Projects;
