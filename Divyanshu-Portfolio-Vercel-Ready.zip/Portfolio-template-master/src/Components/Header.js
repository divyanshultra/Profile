import React from "react";
import TypeWriter from "react-typewriter";

const Header = ({ data = {} }) => (
  <header id="home">
    <nav id="nav-wrap">
      <a className="mobile-btn" href="#nav-wrap" title="Show navigation">Show navigation</a>
      <a className="mobile-btn" href="#home" title="Hide navigation">Hide navigation</a>
      <ul id="nav" className="nav">
        <li className="current"><a className="smoothscroll" href="#home">Home</a></li>
        <li><a className="smoothscroll" href="#about">About</a></li>
        <li><a className="smoothscroll" href="#resume">Skills</a></li>
        <li><a className="smoothscroll" href="#portfolio">Projects</a></li>
        <li><a className="smoothscroll" href="#contact">Contact</a></li>
      </ul>
    </nav>
    <div className="row banner">
      <div className="banner-text">
        <h1 className="responsive-headline"><TypeWriter typing={0.5}>{data.name ? `I'm ${data.name}.` : ""}</TypeWriter></h1>
        <h3>{data.address && data.address.city ? `Based in ${data.address.city}, ${data.address.state}. ` : ""}<span>{data.occupation}</span>. {data.description}</h3>
        <hr />
      </div>
    </div>
    <p className="scrolldown"><a className="smoothscroll" href="#about"><i className="icon-down-circle"></i></a></p>
  </header>
);
export default Header;
