import React from "react";

const Contact = ({ data = {} }) => (
  <section id="contact">
    <div className="row section-head">
      <div className="two columns header-col"><h1><span>Get In Touch.</span></h1></div>
      <div className="ten columns"><p className="lead">{data.contactmessage}</p></div>
    </div>
    <div className="row">
      <div className="eight columns">
        <p>Public email and social links are not published yet. Please check back later for contact details.</p>
      </div>
    </div>
  </section>
);
export default Contact;
